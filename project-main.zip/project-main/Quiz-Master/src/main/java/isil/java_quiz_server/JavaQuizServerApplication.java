package isil.java_quiz_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaQuizServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(JavaQuizServerApplication.class, args);
	}

}
